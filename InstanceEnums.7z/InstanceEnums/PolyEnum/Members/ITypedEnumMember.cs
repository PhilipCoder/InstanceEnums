﻿namespace TypedEnums
{
    public interface ITypedEnumMember
    {
        int EnumValue { get; set; }

        string Name { get; set; }
    }
}
